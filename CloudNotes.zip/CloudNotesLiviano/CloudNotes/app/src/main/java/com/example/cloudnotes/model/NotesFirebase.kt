package com.example.cloudnotes.model

import androidx.room.PrimaryKey

data class NotesFirebase(

    @PrimaryKey(autoGenerate = true)
    var id: String ="",

    var nameEstudiante: String = "",
    var materia: String ="",
    var nota: Double=0.0,
    var apellido1 : String = "",
    var curso : String="",
    var isSelected: Boolean = false
){
    constructor() : this("", "", "", 0.0,"",)
}