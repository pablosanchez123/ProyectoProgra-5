package com.example.cloudnotes.data

import androidx.lifecycle.LiveData
import com.example.cloudnotes.data.database.interfaces.NotesDao
import com.example.cloudnotes.model.Notes
import javax.inject.Inject

class NotesRepository @Inject constructor(private val notesDao: NotesDao)
{
    fun getAllNotes(): LiveData<List<Notes>> {
        return notesDao.getAllNotes()
    }

    suspend fun insert(notes: Notes) {
        notesDao.insert(notes)
    }

    suspend fun update(notes: Notes) {
        notesDao.update(notes)
    }

    suspend fun deleteAllNotes() {
        notesDao.deleteAllNotes()
    }
    suspend fun delete(notes: Notes) {
        notesDao.delete(notes)
    }

}