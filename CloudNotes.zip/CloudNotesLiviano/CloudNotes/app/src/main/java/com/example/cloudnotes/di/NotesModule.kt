package com.example.cloudnotes.di

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import android.content.Context
import com.example.cloudnotes.data.NotesRepository
import com.example.cloudnotes.data.database.AppDatabase
import com.example.cloudnotes.data.database.Firebase.NotesRepositoryFirebase
import com.example.cloudnotes.data.database.Firebase.Notes_Firebase
import com.example.cloudnotes.data.database.interfaces.NotesDao
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.viewmodel.NoteViewModel
import com.example.cloudnotes.viewmodel.loginViewModel
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule
{
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Provides
    @Singleton
    fun provideNoteDao(appDatabase: AppDatabase): NotesDao {
        return appDatabase.NoteDao()
    }

    @Provides
    @Singleton
    fun provideNoteRepository(notesDao: NotesDao): NotesRepository {
        return NotesRepository(notesDao)
    }

    @Provides
    @Singleton
    fun provideFirebaseDatabase(): FirebaseDatabase = FirebaseDatabase.getInstance()






    @Provides
    @Singleton
    fun provideFirebaseAuth(): FirebaseAuth {
        return Firebase.auth
    }



    @Module
    @InstallIn(SingletonComponent::class)
    object FirebaseModule {
        @Provides
        @Singleton
        fun provideFirestore(): FirebaseFirestore {
            val firestore = Firebase.firestore
            firestore.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(true)
                .build()
            return firestore
        }

        @Provides
        @Singleton
        fun provideNotesFirebase(): Notes_Firebase {
            return Notes_Firebase(Firebase.auth, FirebaseFirestore.getInstance())
        }

        @Provides
        @Singleton
        fun provideItemRepositoryFirebase(
            item_Firebase: Notes_Firebase
        ): NotesRepositoryFirebase {
            return NotesRepositoryFirebase(item_Firebase)
        }
    }

}