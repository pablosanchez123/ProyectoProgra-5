package com.example.cloudnotes.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cloudnotes.data.NotesRepository
import com.example.cloudnotes.data.database.Firebase.NotesRepositoryFirebase
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.model.NotesFirebase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val repository: NotesRepository,
    private val firebaseRepository : NotesRepositoryFirebase
) : ViewModel() {

    private val _notes = MutableLiveData<List<Notes>>()
    val items: LiveData<List<Notes>> = _notes

    private val _loading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = _loading

    private val _error = MutableLiveData<String?>()
    val error: LiveData<String?> = _error

    val allNotes: LiveData<List<Notes>> get() = repository.getAllNotes()


    fun obtenerNotes(remoteSource: Boolean): LiveData<List<Notes>> {
        _loading.value = true
        _error.value = null

        return if (remoteSource) {
            // Fuente remota (Firebase)
            val liveData = MutableLiveData<List<Notes>>()

            viewModelScope.launch {
                try {
                    firebaseRepository.getAllNotes().observeForever { firebaseItems ->
                        val convertedItems = firebaseItems.map { firebaseItem ->
                            Notes(
                                id = firebaseItem.id.toLongOrNull() ?: 0L,
                                idFirebase = firebaseItem.id ?: "",
                                nameEstudiante = firebaseItem.nameEstudiante,
                                materia = firebaseItem.materia,
                                nota = firebaseItem.nota,
                                apellido1 = firebaseItem.apellido1,
                                curso = firebaseItem.curso,
                                isSelected = firebaseItem.isSelected
                            )
                        }
                        _notes.postValue(convertedItems)
                        liveData.postValue(convertedItems)

                    }
                } catch (e: Exception) {
                    _error.postValue("Error: ${e.message}")
                    liveData.postValue(repository.getAllNotes().value ?: emptyList())
                } finally {
                    _loading.postValue(false)
                }
            }

            liveData
        } else {
            // Fuente local (Repository)
            repository.getAllNotes()
        }
    }

    fun insert(notes: Notes, remoteSource: Boolean) = viewModelScope.launch {
        if (remoteSource) {
            val noteFB = NotesFirebase().apply {
                nameEstudiante = notes.nameEstudiante
                materia = notes.materia
                nota = notes.nota
                apellido1 = notes.apellido1
                curso = notes.curso
                isSelected = notes.isSelected
            }

            firebaseRepository.insert(noteFB)
        } else {
            repository.insert(notes)
        }
    }

    fun update(notes: Notes, remoteSource: Boolean) = viewModelScope.launch {
        if (remoteSource) {
            val noteFB = NotesFirebase().apply {
                id = notes.idFirebase
                nameEstudiante = notes.nameEstudiante
                materia = notes.materia
                nota = notes.nota
                apellido1 = notes.apellido1
                curso = notes.curso
                isSelected = notes.isSelected
            }
            firebaseRepository.update(noteFB)
        } else {
            repository.update(notes)
        }
    }


    fun deleteItem(notes: Notes, remoteSource: Boolean) {
        viewModelScope.launch {
            if (remoteSource) {
                val noteFB = NotesFirebase().apply {
                    id = notes.idFirebase // Aquí el problema si id == 0
                    nameEstudiante = notes.nameEstudiante
                    materia = notes.materia
                    nota = notes.nota
                    apellido1 = notes.apellido1
                    curso = notes.curso
                    isSelected = notes.isSelected
                }

                // Evitar eliminar si el ID no está
                if (noteFB.id.isNullOrEmpty() || noteFB.id == "0") {

                    return@launch
                }

                firebaseRepository.deleteNote(noteFB)
            } else {
                repository.delete(notes)
            }
        }
    }


    fun deleteAllItems(remoteSource: Boolean) = viewModelScope.launch {
        if (remoteSource) firebaseRepository.deleteAllNotes() else repository.deleteAllNotes()
    }
}
