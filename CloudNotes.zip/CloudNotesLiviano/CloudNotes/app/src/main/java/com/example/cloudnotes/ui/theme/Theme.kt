package com.example.cloudnotes.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// Definir colores personalizados
val BluePrimary = Color(0xFF3F51B5)
val DarkBlue = Color(0xFF303F9F)
val LightYellow = Color(0xFFFFEB3B)
val White = Color(0xFFFFFFFF)
val LightGray = Color(0xFFF5F5F5)
val Black = Color(0xFF000000)

// Definir esquemas de color
private val LightColorScheme = lightColorScheme(
    primary = BluePrimary,
    onPrimary = White,
    primaryContainer = DarkBlue,
    onPrimaryContainer = White,
    secondary = LightYellow,
    onSecondary = Black,
    background = LightGray,
    onBackground = Black,
    surface = White,
    onSurface = Black
)

private val DarkColorScheme = darkColorScheme(
    primary = DarkBlue,
    onPrimary = LightYellow,
    primaryContainer = BluePrimary,
    onPrimaryContainer = White,
    secondary = LightYellow,
    onSecondary = Black,
    background = Black,
    onBackground = White,
    surface = DarkBlue,
    onSurface = White
)

// Aplicar los esquemas en el Theme
@Composable
fun CloudNotesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}