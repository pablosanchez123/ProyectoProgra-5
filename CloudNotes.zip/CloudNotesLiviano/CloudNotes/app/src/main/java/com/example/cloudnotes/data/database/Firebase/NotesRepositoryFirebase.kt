package com.example.cloudnotes.data.database.Firebase

import androidx.lifecycle.MutableLiveData
import com.example.cloudnotes.model.NotesFirebase
import javax.inject.Inject

class NotesRepositoryFirebase @Inject constructor(
    private val notes_Firebase: Notes_Firebase
){
    fun getAllNotes(): MutableLiveData<List<NotesFirebase>> {
        return notes_Firebase.getNotes()
    }

    fun insert(note: NotesFirebase, onSuccess: (String) -> Unit = {}) {
        notes_Firebase.saveNote(note, onSuccess)
    }


    suspend fun update(notes: NotesFirebase) {
        notes_Firebase.saveNote(notes)
    }

    suspend fun deleteAllNotes() {
        notes_Firebase.deleteAllNotes()
    }

    suspend fun deleteNote(notes: NotesFirebase) {
        notes_Firebase.deleteNote(notes)
    }
}