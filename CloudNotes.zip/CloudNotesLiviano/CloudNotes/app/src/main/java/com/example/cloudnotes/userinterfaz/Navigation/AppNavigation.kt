package com.example.cloudnotes.userinterfaz.Navigation

import android.util.Log
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavController
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.navigation
import com.google.gson.Gson
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.userinterfaz.AddNoteScreen
import com.example.cloudnotes.userinterfaz.EditNoteScreen
import com.example.cloudnotes.userinterfaz.NoteListScreen
import com.example.cloudnotes.userinterfaz.login.LoginScreen
import com.example.cloudnotes.userinterfaz.login.RegisterScreen
import com.example.cloudnotes.viewmodel.NoteViewModel
import com.example.cloudnotes.viewmodel.loginViewModel

@Composable
fun AppNavigation(
    viewModelStoreOwner: ViewModelStoreOwner = LocalViewModelStoreOwner.current!!
) {
    val navController = rememberNavController()
    val authViewModel: loginViewModel = hiltViewModel()
    val currentUser by authViewModel.currentUser

    // Redirección basada en autenticación
    LaunchedEffect(currentUser) {
        if (currentUser != null && navController.currentDestination?.route?.startsWith("auth/") == true) {
            navController.navigate("noteList") {
                popUpTo("auth") { inclusive = true }
            }
        } else if (currentUser == null && navController.currentDestination?.route?.startsWith("auth/") != true) {
            navController.navigate("auth") {
                popUpTo(navController.graph.startDestinationId) { inclusive = true }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = if (currentUser != null) "noteList" else "auth"
    ) {
        // Grupo de rutas de autenticación
        authNavigation(navController, viewModelStoreOwner, authViewModel)

        // Grupo de rutas del CRUD (solo accesibles autenticados)
        crudNavigation(navController, viewModelStoreOwner)
    }
}
private fun NavGraphBuilder.authNavigation(
    navController: NavController,
    viewModelStoreOwner: ViewModelStoreOwner,
    authViewModel: loginViewModel
) {
    navigation(startDestination = "login", route = "auth") {
        composable("login") {
            LoginScreen(
                onLoginSuccess = { navController.navigate("noteList") {
                    popUpTo("auth") { inclusive = true }
                } },
                onNavigateToRegister = { navController.navigate("register") },
                viewModel = authViewModel
            )
        }

        composable("register") {
            RegisterScreen(
                onRegisterSuccess = { navController.navigate("noteList") {
                    popUpTo("auth") { inclusive = true }
                }},
                onNavigateToLogin = { navController.popBackStack() },
                viewModel = authViewModel
            )
        }
    }
}

private fun NavGraphBuilder.crudNavigation(
    navController: NavController,
    viewModelStoreOwner: ViewModelStoreOwner
) {
    composable("noteList") {
        val authViewModel: loginViewModel = hiltViewModel(viewModelStoreOwner)
        val noteViewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)

        NoteListScreen(
            navController = navController,
            viewModel = noteViewModel,
            onLogout = {
                authViewModel.logout()
                navController.navigate("auth") {
                    popUpTo("noteList") { inclusive = true }
                }
            }
        )
    }

    composable("addNote") {
        val noteViewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)
        AddNoteScreen(
            navController = navController,
            viewModel = noteViewModel
        )
    }

    composable(
        route = "editNote/{noteJson}",
        arguments = listOf(
            navArgument("noteJson") {
                type = NavType.StringType
            }
        )
    ) { backStackEntry ->
        val rawJson = backStackEntry.arguments?.getString("noteJson")
        Log.d("DEBUG_JSON", "Raw JSON recibido: $rawJson")
        val note = Gson().fromJson(rawJson, Notes::class.java)
        val noteViewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)

        if (note != null) {
            EditNoteScreen(
                notes = note,
                viewModel = noteViewModel,
                navController = navController
            )
        }
    }
}