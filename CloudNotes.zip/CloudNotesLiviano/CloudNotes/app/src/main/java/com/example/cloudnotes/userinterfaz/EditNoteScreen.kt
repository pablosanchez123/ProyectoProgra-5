package com.example.cloudnotes.userinterfaz

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.viewmodel.NoteViewModel


@Composable
fun EditNoteScreen(
    notes: Notes,
    viewModel: NoteViewModel = hiltViewModel(),
    navController: NavController
) {
    var studentName by remember { mutableStateOf("") }
    var subject by remember { mutableStateOf("") }
    var noteValue by remember { mutableStateOf("") }
    var apellido by remember { mutableStateOf("") }
    var curso by remember { mutableStateOf("") }

    // ✅ Esto asegura que los datos iniciales se cargan correctamente
    LaunchedEffect(notes) {
        studentName = notes.nameEstudiante
        subject = notes.materia
        noteValue = notes.nota.toString()
        apellido = notes.apellido1
        curso = notes.curso
    }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        OutlinedTextField(
            value = studentName,
            onValueChange = { studentName = it },
            label = { Text("Nombre del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = apellido,
            onValueChange = { apellido = it },
            label = { Text("Apellido") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = curso,
            onValueChange = { curso = it },
            label = { Text("Curso") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = subject,
            onValueChange = { subject = it },
            label = { Text("Materia") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = noteValue,
            onValueChange = {
                if (it.matches(Regex("^\\d*\\.?\\d*\$"))) noteValue = it
            },
            label = { Text("Nota") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val notaFinal = noteValue.toDoubleOrNull() ?: 0.0

                val notaEditada = notes.copy(
                    nameEstudiante = studentName,
                    apellido1 = apellido,
                    curso = curso,
                    materia = subject,
                    nota = notaFinal
                )

                viewModel.update(notaEditada, true)
                navController.popBackStack()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar cambios")
        }
    }
}



