package com.example.cloudnotes.data.database.Firebase

import android.util.Log
import androidx.lifecycle.MutableLiveData
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.DocumentReference
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.ktx.Firebase
import com.example.cloudnotes.data.database.interfaces.NotesDao
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.model.NotesFirebase
import javax.inject.Inject

class Notes_Firebase @Inject constructor(private val auth: FirebaseAuth, private val firestore: FirebaseFirestore){

    private val coleccion1 = "NotesApp"
    private val coleccion2 = "UserNotes"

    private val usuario: String
        get() = auth.currentUser?.email ?: throw IllegalStateException("Usuario no autenticado")

    fun saveNote(note: NotesFirebase, onSuccess: (String) -> Unit = {}, onError: (Exception) -> Unit = {}) {
        val collectionRef = firestore
            .collection(coleccion1)
            .document(usuario)
            .collection(coleccion2)

        val documentRef = if (note.id.isNullOrEmpty()) {
            val newDocRef = collectionRef.document()
            note.id = newDocRef.id
            newDocRef
        } else {
            collectionRef.document(note.id)
        }

        documentRef.set(note)
            .addOnSuccessListener {
                Log.d("Firestore", "Nota guardada exitosamente")
                onSuccess(note.id!!) // <- Devuelve el id asignado
            }
            .addOnFailureListener { e ->
                Log.e("Firestore", "Error al guardar documento", e)
                onError(e)
            }
    }



    fun deleteNote(Notes: NotesFirebase){

        if(Notes.id.isNotEmpty()){
            firestore
                .collection(coleccion1)
                .document(usuario)
                .collection(coleccion2)
                .document(Notes.id)
                .delete()

                .addOnSuccessListener {
                    Log.d("DeleteObjeto","Objeto eliminado")
                }
                .addOnCanceledListener {
                    Log.e("DeleteObjeto","Objeto NO eliminado")

                }
        }
    }

    fun getNotes() : MutableLiveData<List<NotesFirebase>> {
        val listaItems = MutableLiveData<List<NotesFirebase>>()

        firestore
            .collection(coleccion1)
            .document(usuario)
            .collection(coleccion2)
            .addSnapshotListener{ instantenea, error->

                if(error!=null){
                    return@addSnapshotListener
                }
                if(instantenea != null){

                    val lista = ArrayList<NotesFirebase>()
                    instantenea.documents.forEach{
                        var objetos = it.toObject(NotesFirebase::class.java)
                        if(objetos!=null)
                        {
                            lista.add(objetos)
                        }
                    }
                    listaItems.value = lista
                }

            }

        return listaItems
    }

    fun deleteAllNotes(){
        val resultLiveData = MutableLiveData<Boolean>()

        val notesRef = firestore
            .collection(coleccion1)
            .document(usuario)
            .collection(coleccion2)

        notesRef.get()
            .addOnSuccessListener { querySnapshot ->
                // Iniciar batch delete
                val batch = firestore.batch()

                querySnapshot.documents.forEach { document ->
                    batch.delete(document.reference)
                }

                batch.commit()
                    .addOnSuccessListener {
                        Log.d("DeleteAll", "Todos los items eliminados exitosamente")
                        resultLiveData.value = true
                    }
                    .addOnFailureListener { e ->
                        Log.e("DeleteAll", "Error al eliminar items: ${e.message}")
                        resultLiveData.value = false
                    }
            }
            .addOnFailureListener { e ->
                Log.e("DeleteAll", "Error al obtener items para eliminar: ${e.message}")
                resultLiveData.value = false
            }


    }



}