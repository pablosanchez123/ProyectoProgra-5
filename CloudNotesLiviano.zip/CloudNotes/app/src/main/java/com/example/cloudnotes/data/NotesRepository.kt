package com.example.cloudnotes.data

import androidx.lifecycle.LiveData
import com.example.cloudnotes.data.database.interfaces.NotesDao
import com.example.cloudnotes.model.Notes
import javax.inject.Inject

class NotesRepository @Inject constructor(private val houseDao: NotesDao)
{
    fun getAllNotes(): LiveData<List<Notes>> {
        return houseDao.getAllNotes()
    }

    suspend fun insert(notes: Notes) {
        houseDao.insert(notes)
    }

    suspend fun update(notes: Notes) {
        houseDao.update(notes)
    }

    suspend fun deleteAllNotes() {
        houseDao.deleteAllNotes()
    }
    suspend fun delete(notes: Notes) {
        houseDao.delete(notes)
    }

}