package com.example.cloudnotes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import com.example.cloudnotes.ui.theme.CloudNotesTheme
import com.example.cloudnotes.userinterfaz.navigation.Navigation
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CloudNotesTheme {  // Usando el tema corregido
                Scaffold { paddingValues ->
                    Navigation(modifier = Modifier.padding(paddingValues))
                }
            }
        }
    }
}
