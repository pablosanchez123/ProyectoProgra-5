package com.example.cloudnotes.userinterfaz

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.viewmodel.NoteViewModel

@Composable
fun AddNoteScreen(
    navController: NavController,
    viewModel: NoteViewModel = hiltViewModel()
) {
    var materiaName by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var nameEst by remember { mutableStateOf("") }
    var curso by remember { mutableStateOf("") }
    var apellidoEst by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        OutlinedTextField(
            value = materiaName,
            onValueChange = { materiaName = it },
            label = { Text("Nombre de la materia") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = nameEst,
            onValueChange = { nameEst = it },
            label = { Text("Nombre del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = apellidoEst,
            onValueChange = { apellidoEst = it },
            label = { Text("Apellido del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = curso,
            onValueChange = { curso = it },
            label = { Text("Curso del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = note,
            onValueChange = { newValue ->
                if (newValue.toDoubleOrNull() != null) note = newValue
            },
            label = { Text("Nota del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                if (materiaName.isNotBlank() && note.toDoubleOrNull() != null) {
                    val newNote = Notes(
                        materia = materiaName,
                        nota = note.toDouble()
                    )
                    viewModel.insert(newNote)
                    navController.popBackStack()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Agregar nota")
        }
    }
}
