package com.example.cloudnotes.userinterfaz

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.pullrefresh.PullRefreshIndicator
import androidx.compose.material.pullrefresh.pullRefresh
import androidx.compose.material.pullrefresh.rememberPullRefreshState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.viewmodel.NoteViewModel
import com.google.gson.Gson
import kotlinx.coroutines.launch
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import kotlin.math.abs

@OptIn(ExperimentalMaterialApi::class)
@Composable
fun NoteListScreen(
    navController: NavController = rememberNavController(),
    viewModel: NoteViewModel = hiltViewModel()
) {
    val notes by viewModel.allNotes.observeAsState(emptyList<Notes>())

    var noteToDelete by remember { mutableStateOf<Notes?>(null) }
    var cancelSwipeAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var isRefreshing by remember { mutableStateOf(false) }

    val pullRefreshState = rememberPullRefreshState(
        refreshing = isRefreshing,
        onRefresh = {
            isRefreshing = true
            isRefreshing = false
        }
    )

    // Diálogo de confirmación de eliminación
    if (noteToDelete != null) {
        AlertDialog(
            onDismissRequest = { noteToDelete = null },
            title = { Text(text = "Confirmar borrado") },
            text = { Text(text = "¿Estás seguro de que quieres borrar esta nota?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        noteToDelete?.let {
                            viewModel.deleteItem(it)
                            noteToDelete = null
                        }
                    }
                ) {
                    Text("Eliminar", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = {
                        noteToDelete = null
                        cancelSwipeAction?.invoke()
                    }
                ) {
                    Text("Cancelar")
                }
            }
        )
    }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    navController.navigate("addNote")
                },
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = "Agregar nota"
                )
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Text(
                text = "Notas registradas: ${notes.size}",
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier
                    .padding(16.dp)
                    .fillMaxWidth()
            )

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .pullRefresh(pullRefreshState)
            ) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp)
                ) {
                    items(notes.size) { index ->
                        val note = notes[index]
                        NoteCard(
                            note = note,
                            onClick = { viewModel.update(note.copy(materia = note.materia)) },
                            onSwipe = {
                                noteToDelete = note
                                cancelSwipeAction = null
                            },
                            onEditClick = {
                                val json = Gson().toJson(note)
                                val encodedJson =
                                    URLEncoder.encode(json, StandardCharsets.UTF_8.toString())
                                navController.navigate("editNote/$encodedJson")
                            },
                            onDeleteClick = { noteToDelete = note },
                            onCancelSwipe = { cancelSwipeAction = it }
                        )
                    }
                }

                PullRefreshIndicator(
                    refreshing = isRefreshing,
                    state = pullRefreshState,
                    modifier = Modifier.align(Alignment.TopCenter)
                )
            }
        }
    }
}

@Composable
fun NoteCard(
    note: Notes,
    onClick: () -> Unit,
    onSwipe: () -> Unit,
    onEditClick: () -> Unit,
    onDeleteClick: () -> Unit,
    onCancelSwipe: (() -> Unit) -> Unit
) {
    val offsetX = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .offset { IntOffset(offsetX.value.toInt(), 0) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        if (abs(offsetX.value) > 300f) {
                            scope.launch {
                                offsetX.animateTo(
                                    targetValue = if (offsetX.value > 0) 1000f else -1000f,
                                    animationSpec = tween(durationMillis = 300)
                                )
                                onSwipe()
                            }
                        } else {
                            scope.launch { offsetX.animateTo(0f, tween(300)) }
                        }
                    }
                ) { _, dragAmount ->
                    scope.launch { offsetX.snapTo(offsetX.value + dragAmount) }
                }
            }
            .clickable { onClick() },
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        border = CardDefaults.outlinedCardBorder()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = note.materia,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "Nota: ${note.nota}",
                style = MaterialTheme.typography.bodyMedium
            )
            Row {
                IconButton(onClick = { onEditClick() }) {
                    Icon(imageVector = Icons.Default.Edit, contentDescription = "Editar")
                }
                IconButton(
                    onClick = { onDeleteClick() },
                    colors = IconButtonDefaults.iconButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Eliminar")
                }
            }
        }
    }

    LaunchedEffect(key1 = note) {
        onCancelSwipe {
            scope.launch { offsetX.animateTo(0f, tween(300)) }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun NoteListScreenPreview() {
    NoteListScreen()
}
