package com.example.cloudnotes.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

@Entity(tableName = "notes")
data class Notes(

    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val nameEstudiante: String = "",
    val materia: String ="",
    val nota: Double=0.0,
    val apellido1 : String = "",
    val curso : String="",
    val isSelected: Boolean = false
) : Serializable