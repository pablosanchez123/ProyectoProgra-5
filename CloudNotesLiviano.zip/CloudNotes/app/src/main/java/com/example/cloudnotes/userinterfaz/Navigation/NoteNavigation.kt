package com.example.cloudnotes.userinterfaz.navigation

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.viewmodel.compose.LocalViewModelStoreOwner
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.userinterfaz.AddNoteScreen
import com.example.cloudnotes.userinterfaz.EditNoteScreen
import com.example.cloudnotes.userinterfaz.NoteListScreen
import com.example.cloudnotes.viewmodel.NoteViewModel
import com.google.gson.Gson

@Composable
fun Navigation(
    modifier: Modifier = Modifier, // ✅ Se agregó el `modifier` aquí
    viewModelStoreOwner: ViewModelStoreOwner = LocalViewModelStoreOwner.current!!
) {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = "noteList",
        modifier = modifier // ✅ Se usa el `modifier` aquí para evitar errores
    ) {
        // Pantalla principal - Lista de notas
        composable("noteList") {
            val viewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)
            NoteListScreen(navController = navController, viewModel = viewModel)
        }

        // Pantalla para agregar una nueva nota
        composable("addNote") {
            val viewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)
            AddNoteScreen(navController = navController, viewModel = viewModel)
        }

        // Pantalla para editar una nota
        composable(
            route = "editNote/{itemJson}",
            arguments = listOf(navArgument("itemJson") { type = NavType.StringType })
        ) { backStackEntry ->
            val json = backStackEntry.arguments?.getString("itemJson")
            val note = json?.let { Gson().fromJson(it, Notes::class.java) }

            val viewModel: NoteViewModel = hiltViewModel(viewModelStoreOwner)

            if (note != null) {
                EditNoteScreen(notes = note, viewModel = viewModel, navController = navController)
            } else {
                navController.popBackStack() // Regresa si no se pudo obtener la nota
            }
        }
    }
}
