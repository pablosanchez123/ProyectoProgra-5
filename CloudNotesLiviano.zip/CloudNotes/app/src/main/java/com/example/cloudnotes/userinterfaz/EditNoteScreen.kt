package com.example.cloudnotes.userinterfaz

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavController
import com.example.cloudnotes.model.Notes
import com.example.cloudnotes.viewmodel.NoteViewModel

@Composable
fun EditNoteScreen(
    notes: Notes,
    viewModel: NoteViewModel = hiltViewModel(),
    navController: NavController
) {
    var noteEst by remember { mutableStateOf(notes.nota.toString()) }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp)
    ) {
        OutlinedTextField(
            value = noteEst,
            onValueChange = { newValue ->
                if (newValue.matches(Regex("^\\d*\\.?\\d*\$"))) noteEst = newValue
            },
            label = { Text("Nueva nota del estudiante") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                val updatedNote = noteEst.toDoubleOrNull() ?: notes.nota
                if (updatedNote > 0.0) {
                    val notasActualizadas = notes.copy(nota = updatedNote)
                    viewModel.update(notasActualizadas)
                    navController.popBackStack()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Guardar cambios")
        }
    }
}
