package com.example.cloudnotes.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.cloudnotes.data.NotesRepository
import com.example.cloudnotes.model.Notes
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class NoteViewModel @Inject constructor(
    private val repository: NotesRepository
) : ViewModel() {

    val allNotes: LiveData<List<Notes>> get() = repository.getAllNotes()


    fun insert(notes: Notes) = viewModelScope.launch {
        repository.insert(notes)
    }

    fun update(notes: Notes) = viewModelScope.launch {
        repository.update(notes)
    }

    fun deleteItem(notes: Notes) {
        viewModelScope.launch {
            repository.delete(notes)
        }
    }

    fun deleteAllItems() = viewModelScope.launch {
        repository.deleteAllNotes()
    }
}
