package com.example.cloudnotes.di

import android.content.Context
import com.example.cloudnotes.data.NotesRepository
import com.example.cloudnotes.data.database.AppDatabase
import com.example.cloudnotes.data.database.interfaces.NotesDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule
{
    @Provides
    @Singleton
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Provides
    @Singleton
    fun provideNoteDao(appDatabase: AppDatabase): NotesDao {
        return appDatabase.NoteDao()
    }

    @Provides
    @Singleton
    fun provideNoteRepository(notesDao: NotesDao): NotesRepository {
        return NotesRepository(notesDao)
    }

}